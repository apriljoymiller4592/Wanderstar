import os
import time  # Importing time to use for generating unique timestamps

def rename_files_in_directory(directory):
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
    files.sort()  # Sort files to maintain order
    
    start_number = 1
    
    for filename in files:
        name, extension = os.path.splitext(filename)
        new_filename = f"{start_number}{extension}"
        old_file = os.path.join(directory, filename)
        new_file = os.path.join(directory, new_filename)

        # Check if a file with the new filename already exists
        if os.path.exists(new_file):
            # If it exists, append a unique identifier to the filename
            unique_identifier = int(time.time())  # Current Unix timestamp as a unique identifier
            new_filename = f"{start_number}_{unique_identifier}{extension}"
            new_file = os.path.join(directory, new_filename)

        os.rename(old_file, new_file)
        start_number += 1

    print(f"Renamed {start_number-1} files.")

# Replace with the path to your directory
directory_path = "circle"
rename_files_in_directory(directory_path)
directory_path = "triangle"
rename_files_in_directory(directory_path)
directory_path = "z"
rename_files_in_directory(directory_path)
