import os
import csv

csv_file_name = 'data.csv'

# open .csv or make it and open it.
with open(csv_file_name, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['label', 'path'])  # Column headers


    current_directory = os.getcwd()
    Root_Dir = os.path.basename(current_directory)
    print(Root_Dir)

    # Walk through all directories and files in the current directory
    for root, dirs, files in os.walk(current_directory):
        
        for file in files:
            if file.endswith('.png'):
                # Extract the folder name
                folder_name = os.path.basename(root)
                # Construct the path to the file
                relative_path = os.path.relpath(root, current_directory)
                relative_path = os.path.join(Root_Dir, relative_path)
                file_path = os.path.join(relative_path, file)
                print(file_path)
                # Write the folder name and file path to the CSV
                
                writer.writerow([folder_name, file_path])

print(f"Paths to .png files have been stored in {csv_file_name}.")
